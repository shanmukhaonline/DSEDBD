import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'viraham_restaurant',
  port: Number(process.env.DB_PORT) || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
};

export let pool: mysql.Pool | null = null;
let isDbConnected = false;

try {
  pool = mysql.createPool(dbConfig);
} catch (err) {
  console.warn('MySQL pool creation warning:', err);
}

export async function checkDbConnection(): Promise<boolean> {
  if (!pool) return false;
  try {
    const connection = await pool.getConnection();
    await connection.ping();
    connection.release();
    isDbConnected = true;
    return true;
  } catch (err) {
    isDbConnected = false;
    return false;
  }
}

export function isConnected(): boolean {
  return isDbConnected;
}

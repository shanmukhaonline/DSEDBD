export const menuItems = [
  {
    "id": 1,
    "name": "Idli",
    "category": "Breakfast",
    "type": "VEG",
    "price": 60,
    "description": "Soft steamed idlis served with sambar and chutney."
  },
  {
    "id": 2,
    "name": "Medu Vada",
    "category": "Breakfast",
    "type": "VEG",
    "price": 70,
    "description": "Crispy South Indian lentil fritters served with chutney."
  },
  {
    "id": 3,
    "name": "Masala Dosa",
    "category": "Breakfast",
    "type": "VEG",
    "price": 110,
    "description": "Crispy dosa filled with flavorful potato masala."
  },
  {
    "id": 4,
    "name": "Plain Dosa",
    "category": "Breakfast",
    "type": "VEG",
    "price": 80,
    "description": "Crispy traditional South Indian dosa."
  },
  {
    "id": 5,
    "name": "Onion Dosa",
    "category": "Breakfast",
    "type": "VEG",
    "price": 100,
    "description": "Crispy dosa topped with fresh onions and spices."
  },
  {
    "id": 6,
    "name": "Rava Dosa",
    "category": "Breakfast",
    "type": "VEG",
    "price": 110,
    "description": "Thin crispy dosa made with semolina and spices."
  },
  {
    "id": 7,
    "name": "Mysore Masala Dosa",
    "category": "Breakfast",
    "type": "VEG",
    "price": 130,
    "description": "Spicy Mysore-style dosa with potato filling."
  },
  {
    "id": 8,
    "name": "Set Dosa",
    "category": "Breakfast",
    "type": "VEG",
    "price": 90,
    "description": "Soft fluffy dosa served with chutney and sambar."
  },
  {
    "id": 9,
    "name": "Pesarattu",
    "category": "Breakfast",
    "type": "VEG",
    "price": 100,
    "description": "Healthy green gram dosa with fresh ginger and chilli."
  },
  {
    "id": 10,
    "name": "Upma",
    "category": "Breakfast",
    "type": "VEG",
    "price": 60,
    "description": "Classic South Indian semolina breakfast."
  },
  {
    "id": 11,
    "name": "Vegetable Upma",
    "category": "Breakfast",
    "type": "VEG",
    "price": 75,
    "description": "Upma cooked with fresh vegetables and spices."
  },
  {
    "id": 12,
    "name": "Poha",
    "category": "Breakfast",
    "type": "VEG",
    "price": 65,
    "description": "Flattened rice cooked with vegetables and mild spices."
  },
  {
    "id": 13,
    "name": "Pongal",
    "category": "Breakfast",
    "type": "VEG",
    "price": 80,
    "description": "Creamy rice and lentil dish tempered with spices."
  },
  {
    "id": 14,
    "name": "Ven Pongal",
    "category": "Breakfast",
    "type": "VEG",
    "price": 90,
    "description": "Traditional South Indian savory pongal."
  },
  {
    "id": 15,
    "name": "Poori with Potato Curry",
    "category": "Breakfast",
    "type": "VEG",
    "price": 100,
    "description": "Fluffy fried pooris served with potato curry."
  },
  {
    "id": 16,
    "name": "Chapati with Veg Kurma",
    "category": "Breakfast",
    "type": "VEG",
    "price": 110,
    "description": "Soft chapati served with creamy vegetable kurma."
  },
  {
    "id": 17,
    "name": "Aloo Paratha",
    "category": "Breakfast",
    "type": "VEG",
    "price": 110,
    "description": "Stuffed Indian flatbread filled with seasoned potato."
  },
  {
    "id": 18,
    "name": "Paneer Paratha",
    "category": "Breakfast",
    "type": "VEG",
    "price": 130,
    "description": "Stuffed paratha filled with spiced paneer."
  },
  {
    "id": 19,
    "name": "Sabudana Khichdi",
    "category": "Breakfast",
    "type": "VEG",
    "price": 90,
    "description": "Tapioca pearls cooked with peanuts and mild spices."
  },
  {
    "id": 20,
    "name": "Moong Dal Chilla",
    "category": "Breakfast",
    "type": "VEG",
    "price": 100,
    "description": "Healthy savory pancakes made from green gram."
  },
  {
    "id": 21,
    "name": "Veg Meals",
    "category": "Lunch",
    "type": "VEG",
    "price": 180,
    "description": "Complete vegetarian meal with rice, curry and sides."
  },
  {
    "id": 22,
    "name": "Andhra Veg Meals",
    "category": "Lunch",
    "type": "VEG",
    "price": 200,
    "description": "Traditional Andhra vegetarian meal with flavorful sides."
  },
  {
    "id": 23,
    "name": "South Indian Thali",
    "category": "Lunch",
    "type": "VEG",
    "price": 220,
    "description": "Traditional South Indian thali with multiple dishes."
  },
  {
    "id": 24,
    "name": "North Indian Thali",
    "category": "Lunch",
    "type": "VEG",
    "price": 240,
    "description": "Complete North Indian thali with breads and curries."
  },
  {
    "id": 25,
    "name": "Veg Biryani",
    "category": "Lunch",
    "type": "VEG",
    "price": 180,
    "description": "Aromatic basmati rice cooked with fresh vegetables."
  },
  {
    "id": 26,
    "name": "Paneer Biryani",
    "category": "Lunch",
    "type": "VEG",
    "price": 220,
    "description": "Fragrant basmati biryani with delicious paneer."
  },
  {
    "id": 27,
    "name": "Mushroom Biryani",
    "category": "Lunch",
    "type": "VEG",
    "price": 210,
    "description": "Aromatic biryani prepared with spiced mushrooms."
  },
  {
    "id": 28,
    "name": "Kaju Biryani",
    "category": "Lunch",
    "type": "VEG",
    "price": 230,
    "description": "Rich biryani prepared with roasted cashews."
  },
  {
    "id": 29,
    "name": "Veg Pulao",
    "category": "Lunch",
    "type": "VEG",
    "price": 150,
    "description": "Fragrant rice cooked with mixed vegetables."
  },
  {
    "id": 30,
    "name": "Peas Pulao",
    "category": "Lunch",
    "type": "VEG",
    "price": 140,
    "description": "Basmati rice cooked with green peas and spices."
  },
  {
    "id": 31,
    "name": "Jeera Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 120,
    "description": "Steamed basmati rice tempered with cumin."
  },
  {
    "id": 32,
    "name": "Curd Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 100,
    "description": "Cooling yogurt rice tempered with South Indian spices."
  },
  {
    "id": 33,
    "name": "Lemon Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 100,
    "description": "Tangy rice flavored with fresh lemon and spices."
  },
  {
    "id": 34,
    "name": "Tamarind Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 100,
    "description": "Tangy South Indian rice made with tamarind."
  },
  {
    "id": 35,
    "name": "Tomato Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 110,
    "description": "Flavorful rice cooked with ripe tomatoes and spices."
  },
  {
    "id": 36,
    "name": "Rajma Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 160,
    "description": "Kidney bean curry served with steamed rice."
  },
  {
    "id": 37,
    "name": "Dal Tadka with Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 150,
    "description": "Yellow dal tempered with spices and served with rice."
  },
  {
    "id": 38,
    "name": "Paneer Butter Masala with Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 220,
    "description": "Creamy paneer butter masala served with rice."
  },
  {
    "id": 39,
    "name": "Chole Bhature",
    "category": "Lunch",
    "type": "VEG",
    "price": 180,
    "description": "Spiced chickpea curry served with fluffy bhature."
  },
  {
    "id": 40,
    "name": "Veg Fried Rice",
    "category": "Lunch",
    "type": "VEG",
    "price": 160,
    "description": "Indo-Chinese fried rice with fresh vegetables."
  },
  {
    "id": 41,
    "name": "Samosa",
    "category": "Snacks",
    "type": "VEG",
    "price": 50,
    "description": "Crispy pastry filled with spiced potato."
  },
  {
    "id": 42,
    "name": "Onion Samosa",
    "category": "Snacks",
    "type": "VEG",
    "price": 50,
    "description": "Crispy samosa filled with spiced onions."
  },
  {
    "id": 43,
    "name": "Mirchi Bajji",
    "category": "Snacks",
    "type": "VEG",
    "price": 60,
    "description": "Green chillies coated in seasoned batter and fried."
  },
  {
    "id": 44,
    "name": "Aloo Bajji",
    "category": "Snacks",
    "type": "VEG",
    "price": 60,
    "description": "Potato slices coated in spiced batter and fried."
  },
  {
    "id": 45,
    "name": "Punugulu",
    "category": "Snacks",
    "type": "VEG",
    "price": 70,
    "description": "Crispy South Indian rice and lentil fritters."
  },
  {
    "id": 46,
    "name": "Garelu",
    "category": "Snacks",
    "type": "VEG",
    "price": 70,
    "description": "Crispy South Indian medu vada-style fritters."
  },
  {
    "id": 47,
    "name": "Masala Vada",
    "category": "Snacks",
    "type": "VEG",
    "price": 60,
    "description": "Crunchy lentil fritters with onions and spices."
  },
  {
    "id": 48,
    "name": "Vegetable Pakora",
    "category": "Snacks",
    "type": "VEG",
    "price": 80,
    "description": "Mixed vegetables coated in spiced gram flour batter."
  },
  {
    "id": 49,
    "name": "Paneer Pakora",
    "category": "Snacks",
    "type": "VEG",
    "price": 120,
    "description": "Crispy paneer pieces coated in spiced batter."
  },
  {
    "id": 50,
    "name": "Veg Cutlet",
    "category": "Snacks",
    "type": "VEG",
    "price": 90,
    "description": "Crispy vegetable and potato cutlet."
  },
  {
    "id": 51,
    "name": "Vegetable Spring Rolls",
    "category": "Snacks",
    "type": "VEG",
    "price": 110,
    "description": "Crispy rolls filled with seasoned vegetables."
  },
  {
    "id": 52,
    "name": "French Fries",
    "category": "Snacks",
    "type": "VEG",
    "price": 100,
    "description": "Golden crispy potato fries."
  },
  {
    "id": 53,
    "name": "Peri Peri Fries",
    "category": "Snacks",
    "type": "VEG",
    "price": 120,
    "description": "Crispy fries tossed with peri peri seasoning."
  },
  {
    "id": 54,
    "name": "Cheese Balls",
    "category": "Snacks",
    "type": "VEG",
    "price": 130,
    "description": "Crispy snack filled with melted cheese."
  },
  {
    "id": 55,
    "name": "Veg Sandwich",
    "category": "Snacks",
    "type": "VEG",
    "price": 100,
    "description": "Fresh vegetable sandwich with flavorful seasoning."
  },
  {
    "id": 56,
    "name": "Grilled Cheese Sandwich",
    "category": "Snacks",
    "type": "VEG",
    "price": 130,
    "description": "Grilled sandwich filled with melted cheese."
  },
  {
    "id": 57,
    "name": "Paneer Sandwich",
    "category": "Snacks",
    "type": "VEG",
    "price": 150,
    "description": "Sandwich filled with seasoned paneer."
  },
  {
    "id": 58,
    "name": "Veg Burger",
    "category": "Snacks",
    "type": "VEG",
    "price": 140,
    "description": "Vegetable patty burger with fresh toppings."
  },
  {
    "id": 59,
    "name": "Paneer Burger",
    "category": "Snacks",
    "type": "VEG",
    "price": 170,
    "description": "Paneer patty burger with sauces and vegetables."
  },
  {
    "id": 60,
    "name": "Corn Cheese Toast",
    "category": "Snacks",
    "type": "VEG",
    "price": 130,
    "description": "Toast topped with creamy corn and cheese."
  },
  {
    "id": 61,
    "name": "Paneer Tikka Masala",
    "category": "Dinner",
    "type": "VEG",
    "price": 240,
    "description": "Grilled paneer cooked in rich spiced gravy."
  },
  {
    "id": 62,
    "name": "Kadai Paneer",
    "category": "Dinner",
    "type": "VEG",
    "price": 230,
    "description": "Paneer cooked with capsicum and kadai spices."
  },
  {
    "id": 63,
    "name": "Palak Paneer",
    "category": "Dinner",
    "type": "VEG",
    "price": 220,
    "description": "Paneer cooked in creamy spinach gravy."
  },
  {
    "id": 64,
    "name": "Shahi Paneer",
    "category": "Dinner",
    "type": "VEG",
    "price": 240,
    "description": "Rich creamy paneer curry with aromatic spices."
  },
  {
    "id": 65,
    "name": "Paneer Korma",
    "category": "Dinner",
    "type": "VEG",
    "price": 250,
    "description": "Mild creamy paneer curry with nuts and spices."
  },
  {
    "id": 66,
    "name": "Malai Kofta",
    "category": "Dinner",
    "type": "VEG",
    "price": 240,
    "description": "Soft vegetable dumplings served in creamy gravy."
  },
  {
    "id": 67,
    "name": "Veg Kolhapuri",
    "category": "Dinner",
    "type": "VEG",
    "price": 200,
    "description": "Mixed vegetables cooked in spicy Kolhapuri masala."
  },
  {
    "id": 68,
    "name": "Veg Handi",
    "category": "Dinner",
    "type": "VEG",
    "price": 200,
    "description": "Mixed vegetables cooked in rich restaurant-style gravy."
  },
  {
    "id": 69,
    "name": "Mix Veg Curry",
    "category": "Dinner",
    "type": "VEG",
    "price": 180,
    "description": "Assorted vegetables cooked in flavorful curry."
  },
  {
    "id": 70,
    "name": "Veg Chettinad",
    "category": "Dinner",
    "type": "VEG",
    "price": 200,
    "description": "Vegetables cooked with aromatic South Indian spices."
  },
  {
    "id": 71,
    "name": "Mushroom Masala",
    "category": "Dinner",
    "type": "VEG",
    "price": 200,
    "description": "Mushrooms cooked in onion-tomato masala."
  },
  {
    "id": 72,
    "name": "Mushroom Pepper Fry",
    "category": "Dinner",
    "type": "VEG",
    "price": 190,
    "description": "Spicy mushroom preparation with black pepper."
  },
  {
    "id": 73,
    "name": "Dal Makhani",
    "category": "Dinner",
    "type": "VEG",
    "price": 180,
    "description": "Creamy slow-cooked black lentils."
  },
  {
    "id": 74,
    "name": "Dal Fry",
    "category": "Dinner",
    "type": "VEG",
    "price": 150,
    "description": "Yellow lentils tempered with aromatic spices."
  },
  {
    "id": 75,
    "name": "Dal Tadka",
    "category": "Dinner",
    "type": "VEG",
    "price": 160,
    "description": "Lentils finished with a flavorful spice tempering."
  },
  {
    "id": 76,
    "name": "Chana Masala",
    "category": "Dinner",
    "type": "VEG",
    "price": 170,
    "description": "Chickpeas cooked in rich tomato and spice gravy."
  },
  {
    "id": 77,
    "name": "Aloo Gobi",
    "category": "Dinner",
    "type": "VEG",
    "price": 160,
    "description": "Potato and cauliflower cooked with Indian spices."
  },
  {
    "id": 78,
    "name": "Baingan Bharta",
    "category": "Dinner",
    "type": "VEG",
    "price": 180,
    "description": "Roasted eggplant cooked with onions and tomatoes."
  },
  {
    "id": 79,
    "name": "Bhindi Masala",
    "category": "Dinner",
    "type": "VEG",
    "price": 170,
    "description": "Okra cooked with onions and Indian spices."
  },
  {
    "id": 80,
    "name": "Veg Korma",
    "category": "Dinner",
    "type": "VEG",
    "price": 200,
    "description": "Mixed vegetables in creamy aromatic gravy."
  },
  {
    "id": 81,
    "name": "Masala Tea",
    "category": "Drinks",
    "type": "VEG",
    "price": 40,
    "description": "Indian tea flavored with aromatic spices."
  },
  {
    "id": 82,
    "name": "Ginger Tea",
    "category": "Drinks",
    "type": "VEG",
    "price": 40,
    "description": "Hot tea infused with fresh ginger."
  },
  {
    "id": 83,
    "name": "Cardamom Tea",
    "category": "Drinks",
    "type": "VEG",
    "price": 45,
    "description": "Fragrant tea flavored with cardamom."
  },
  {
    "id": 84,
    "name": "Filter Coffee",
    "category": "Drinks",
    "type": "VEG",
    "price": 60,
    "description": "Traditional South Indian filter coffee."
  },
  {
    "id": 85,
    "name": "South Indian Coffee",
    "category": "Drinks",
    "type": "VEG",
    "price": 60,
    "description": "Strong aromatic South Indian coffee."
  },
  {
    "id": 86,
    "name": "Cold Coffee",
    "category": "Drinks",
    "type": "VEG",
    "price": 120,
    "description": "Chilled creamy coffee topped with foam."
  },
  {
    "id": 87,
    "name": "Iced Tea",
    "category": "Drinks",
    "type": "VEG",
    "price": 90,
    "description": "Refreshing chilled tea served over ice."
  },
  {
    "id": 88,
    "name": "Lemon Tea",
    "category": "Drinks",
    "type": "VEG",
    "price": 60,
    "description": "Refreshing tea with fresh lemon."
  },
  {
    "id": 89,
    "name": "Green Tea",
    "category": "Drinks",
    "type": "VEG",
    "price": 60,
    "description": "Light and refreshing green tea."
  },
  {
    "id": 90,
    "name": "Fresh Lime Soda",
    "category": "Drinks",
    "type": "VEG",
    "price": 80,
    "description": "Refreshing lime soda with a citrusy taste."
  },
  {
    "id": 91,
    "name": "Sweet Lime Soda",
    "category": "Drinks",
    "type": "VEG",
    "price": 80,
    "description": "Sweet and refreshing lime soda."
  },
  {
    "id": 92,
    "name": "Mango Lassi",
    "category": "Drinks",
    "type": "VEG",
    "price": 120,
    "description": "Creamy mango yogurt drink."
  },
  {
    "id": 93,
    "name": "Sweet Lassi",
    "category": "Drinks",
    "type": "VEG",
    "price": 100,
    "description": "Traditional sweet yogurt-based drink."
  },
  {
    "id": 94,
    "name": "Rose Lassi",
    "category": "Drinks",
    "type": "VEG",
    "price": 110,
    "description": "Refreshing lassi flavored with rose."
  },
  {
    "id": 95,
    "name": "Buttermilk",
    "category": "Drinks",
    "type": "VEG",
    "price": 60,
    "description": "Cooling spiced yogurt buttermilk."
  },
  {
    "id": 96,
    "name": "Mango Milkshake",
    "category": "Drinks",
    "type": "VEG",
    "price": 130,
    "description": "Thick creamy mango milkshake."
  },
  {
    "id": 97,
    "name": "Banana Milkshake",
    "category": "Drinks",
    "type": "VEG",
    "price": 110,
    "description": "Creamy banana milkshake."
  },
  {
    "id": 98,
    "name": "Strawberry Milkshake",
    "category": "Drinks",
    "type": "VEG",
    "price": 140,
    "description": "Rich strawberry milkshake."
  },
  {
    "id": 99,
    "name": "Chocolate Milkshake",
    "category": "Drinks",
    "type": "VEG",
    "price": 150,
    "description": "Thick chocolate milkshake."
  },
  {
    "id": 100,
    "name": "Virgin Mojito",
    "category": "Drinks",
    "type": "VEG",
    "price": 140,
    "description": "Refreshing mint and lime cooler."
  },
  {
    "id": 101,
    "name": "Gulab Jamun",
    "category": "Sweets",
    "type": "VEG",
    "price": 80,
    "description": "Soft milk dumplings soaked in sweet syrup."
  },
  {
    "id": 102,
    "name": "Rasgulla",
    "category": "Sweets",
    "type": "VEG",
    "price": 80,
    "description": "Soft cottage cheese balls soaked in light syrup."
  },
  {
    "id": 103,
    "name": "Rasmalai",
    "category": "Sweets",
    "type": "VEG",
    "price": 120,
    "description": "Soft cheese dumplings served in sweetened milk."
  },
  {
    "id": 104,
    "name": "Jalebi",
    "category": "Sweets",
    "type": "VEG",
    "price": 80,
    "description": "Crispy spiral sweets soaked in sugar syrup."
  },
  {
    "id": 105,
    "name": "Kaju Katli",
    "category": "Sweets",
    "type": "VEG",
    "price": 140,
    "description": "Smooth cashew fudge with a delicate sweetness."
  },
  {
    "id": 106,
    "name": "Motichoor Laddu",
    "category": "Sweets",
    "type": "VEG",
    "price": 100,
    "description": "Soft tiny gram flour pearls shaped into laddus."
  },
  {
    "id": 107,
    "name": "Besan Laddu",
    "category": "Sweets",
    "type": "VEG",
    "price": 90,
    "description": "Traditional gram flour laddus with ghee."
  },
  {
    "id": 108,
    "name": "Boondi Laddu",
    "category": "Sweets",
    "type": "VEG",
    "price": 90,
    "description": "Sweet boondi laddus made with gram flour."
  },
  {
    "id": 109,
    "name": "Mysore Pak",
    "category": "Sweets",
    "type": "VEG",
    "price": 100,
    "description": "Rich traditional South Indian sweet made with ghee."
  },
  {
    "id": 110,
    "name": "Badam Halwa",
    "category": "Sweets",
    "type": "VEG",
    "price": 130,
    "description": "Rich almond-based Indian dessert."
  },
  {
    "id": 111,
    "name": "Carrot Halwa",
    "category": "Sweets",
    "type": "VEG",
    "price": 110,
    "description": "Sweet carrot dessert cooked with milk and nuts."
  },
  {
    "id": 112,
    "name": "Gajar Halwa",
    "category": "Sweets",
    "type": "VEG",
    "price": 110,
    "description": "Traditional carrot halwa with aromatic spices."
  },
  {
    "id": 113,
    "name": "Rice Kheer",
    "category": "Sweets",
    "type": "VEG",
    "price": 100,
    "description": "Creamy rice pudding flavored with cardamom."
  },
  {
    "id": 114,
    "name": "Semiya Payasam",
    "category": "Sweets",
    "type": "VEG",
    "price": 100,
    "description": "Sweet vermicelli pudding cooked with milk."
  },
  {
    "id": 115,
    "name": "Sabudana Kheer",
    "category": "Sweets",
    "type": "VEG",
    "price": 100,
    "description": "Creamy tapioca pudding with milk and cardamom."
  },
  {
    "id": 116,
    "name": "Kulfi",
    "category": "Sweets",
    "type": "VEG",
    "price": 100,
    "description": "Traditional dense Indian frozen dessert."
  },
  {
    "id": 117,
    "name": "Vanilla Ice Cream",
    "category": "Sweets",
    "type": "VEG",
    "price": 90,
    "description": "Smooth classic vanilla ice cream."
  },
  {
    "id": 118,
    "name": "Chocolate Ice Cream",
    "category": "Sweets",
    "type": "VEG",
    "price": 100,
    "description": "Rich creamy chocolate ice cream."
  },
  {
    "id": 119,
    "name": "Butterscotch Ice Cream",
    "category": "Sweets",
    "type": "VEG",
    "price": 100,
    "description": "Creamy butterscotch ice cream with caramel flavor."
  },
  {
    "id": 120,
    "name": "Chocolate Brownie",
    "category": "Sweets",
    "type": "VEG",
    "price": 130,
    "description": "Rich moist chocolate brownie."
  },
  {
    "id": 121,
    "name": "Egg Dosa",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 110,
    "description": "Crispy dosa topped with seasoned egg."
  },
  {
    "id": 122,
    "name": "Egg Omelette",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 80,
    "description": "Fluffy omelette prepared with eggs and spices."
  },
  {
    "id": 123,
    "name": "Masala Omelette",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 90,
    "description": "Spiced omelette with onions and green chillies."
  },
  {
    "id": 124,
    "name": "Chicken Keema Paratha",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 170,
    "description": "Stuffed paratha filled with seasoned chicken keema."
  },
  {
    "id": 125,
    "name": "Egg Paratha",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 120,
    "description": "Indian flatbread stuffed with seasoned egg."
  },
  {
    "id": 126,
    "name": "Chicken Keema Dosa",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 160,
    "description": "Dosa filled with flavorful chicken keema."
  },
  {
    "id": 127,
    "name": "Egg Upma",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 100,
    "description": "Savory upma served with seasoned egg."
  },
  {
    "id": 128,
    "name": "Egg Pesarattu",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 120,
    "description": "Green gram dosa topped with egg."
  },
  {
    "id": 129,
    "name": "Chicken Sandwich",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 160,
    "description": "Sandwich filled with seasoned chicken."
  },
  {
    "id": 130,
    "name": "Chicken Sausage Omelette",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 150,
    "description": "Omelette filled with chicken sausage."
  },
  {
    "id": 131,
    "name": "Egg Bhurji",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 100,
    "description": "Scrambled eggs cooked with onions and spices."
  },
  {
    "id": 132,
    "name": "Bread Omelette",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 100,
    "description": "Bread served with a seasoned egg omelette."
  },
  {
    "id": 133,
    "name": "Egg Masala Toast",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 110,
    "description": "Toast topped with spiced egg mixture."
  },
  {
    "id": 134,
    "name": "Chicken Keema Pav",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 170,
    "description": "Spiced chicken keema served with soft pav."
  },
  {
    "id": 135,
    "name": "Egg Keema Roll",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 150,
    "description": "Egg and spiced filling wrapped in a roll."
  },
  {
    "id": 136,
    "name": "Chicken Mayo Sandwich",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 170,
    "description": "Chicken sandwich with creamy mayonnaise."
  },
  {
    "id": 137,
    "name": "Egg Cheese Sandwich",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 140,
    "description": "Egg and cheese sandwich with fresh bread."
  },
  {
    "id": 138,
    "name": "Chicken Stuffed Paratha",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 180,
    "description": "Indian flatbread stuffed with seasoned chicken."
  },
  {
    "id": 139,
    "name": "Egg Fried Rice",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 130,
    "description": "Fried rice prepared with scrambled egg."
  },
  {
    "id": 140,
    "name": "Chicken Sausage Sandwich",
    "category": "Breakfast",
    "type": "NON_VEG",
    "price": 170,
    "description": "Sandwich filled with chicken sausage."
  },
  {
    "id": 141,
    "name": "Chicken Biryani",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 260,
    "description": "Aromatic basmati rice with tender chicken."
  },
  {
    "id": 142,
    "name": "Mutton Biryani",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 340,
    "description": "Rich basmati biryani with tender mutton."
  },
  {
    "id": 143,
    "name": "Egg Biryani",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 190,
    "description": "Fragrant biryani with boiled eggs."
  },
  {
    "id": 144,
    "name": "Chicken Fry Biryani",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 290,
    "description": "Biryani topped with crispy chicken fry."
  },
  {
    "id": 145,
    "name": "Chicken Dum Biryani",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 280,
    "description": "Slow cooked dum biryani with chicken."
  },
  {
    "id": 146,
    "name": "Mutton Dum Biryani",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 360,
    "description": "Slow cooked dum biryani with mutton."
  },
  {
    "id": 147,
    "name": "Chicken Pulao",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 220,
    "description": "Fragrant rice cooked with chicken."
  },
  {
    "id": 148,
    "name": "Mutton Pulao",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 300,
    "description": "Fragrant rice cooked with mutton."
  },
  {
    "id": 149,
    "name": "Chicken Fried Rice",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 200,
    "description": "Indo-Chinese fried rice with chicken."
  },
  {
    "id": 150,
    "name": "Egg Fried Rice",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 170,
    "description": "Fried rice with scrambled egg."
  },
  {
    "id": 151,
    "name": "Chicken Schezwan Rice",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 220,
    "description": "Spicy Schezwan fried rice with chicken."
  },
  {
    "id": 152,
    "name": "Chicken Meals",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 260,
    "description": "Complete meal with chicken curry, rice and sides."
  },
  {
    "id": 153,
    "name": "Andhra Chicken Meals",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 280,
    "description": "Traditional Andhra chicken meal."
  },
  {
    "id": 154,
    "name": "Mutton Meals",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 340,
    "description": "Complete meal with mutton curry and rice."
  },
  {
    "id": 155,
    "name": "Chicken Curry Rice",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 230,
    "description": "Chicken curry served with steamed rice."
  },
  {
    "id": 156,
    "name": "Mutton Curry Rice",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 300,
    "description": "Mutton curry served with steamed rice."
  },
  {
    "id": 157,
    "name": "Fish Curry Rice",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 240,
    "description": "Fish curry served with rice."
  },
  {
    "id": 158,
    "name": "Prawn Curry Rice",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 280,
    "description": "Prawn curry served with rice."
  },
  {
    "id": 159,
    "name": "Chicken 65 Rice Bowl",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 230,
    "description": "Rice bowl topped with Chicken 65."
  },
  {
    "id": 160,
    "name": "Egg Curry Rice",
    "category": "Lunch",
    "type": "NON_VEG",
    "price": 180,
    "description": "Egg curry served with steamed rice."
  },
  {
    "id": 161,
    "name": "Chicken 65",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 180,
    "description": "Crispy spicy fried chicken pieces."
  },
  {
    "id": 162,
    "name": "Chicken 555",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 190,
    "description": "Spicy Andhra-style crispy chicken."
  },
  {
    "id": 163,
    "name": "Chicken Pakora",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 180,
    "description": "Crispy chicken pieces coated in spiced batter."
  },
  {
    "id": 164,
    "name": "Chicken Majestic",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 200,
    "description": "Tender chicken strips with creamy spicy seasoning."
  },
  {
    "id": 165,
    "name": "Chicken Lollipop",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 220,
    "description": "Fried chicken wings served with spicy sauce."
  },
  {
    "id": 166,
    "name": "Chicken Wings",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 210,
    "description": "Crispy fried chicken wings."
  },
  {
    "id": 167,
    "name": "Chicken Tikka",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 240,
    "description": "Grilled marinated chicken pieces."
  },
  {
    "id": 168,
    "name": "Chicken Seekh Kebab",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 230,
    "description": "Minced chicken kebabs grilled with spices."
  },
  {
    "id": 169,
    "name": "Mutton Seekh Kebab",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 280,
    "description": "Spiced minced mutton grilled on skewers."
  },
  {
    "id": 170,
    "name": "Mutton Shami Kebab",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 260,
    "description": "Soft minced mutton kebabs with aromatic spices."
  },
  {
    "id": 171,
    "name": "Fish Fry",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 220,
    "description": "Crispy shallow-fried marinated fish."
  },
  {
    "id": 172,
    "name": "Apollo Fish",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 240,
    "description": "Spicy crispy fish preparation."
  },
  {
    "id": 173,
    "name": "Chilli Fish",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 230,
    "description": "Crispy fish tossed with chilli and vegetables."
  },
  {
    "id": 174,
    "name": "Prawn Fry",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 280,
    "description": "Spicy fried prawns with herbs and spices."
  },
  {
    "id": 175,
    "name": "Chilli Prawns",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 290,
    "description": "Prawns tossed in spicy chilli sauce."
  },
  {
    "id": 176,
    "name": "Chicken Manchurian",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 210,
    "description": "Chicken pieces in Indo-Chinese Manchurian sauce."
  },
  {
    "id": 177,
    "name": "Chicken 65 Roll",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 180,
    "description": "Chicken 65 wrapped with vegetables and sauces."
  },
  {
    "id": 178,
    "name": "Chicken Cutlet",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 150,
    "description": "Crispy chicken and potato cutlet."
  },
  {
    "id": 179,
    "name": "Egg Bonda",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 120,
    "description": "Boiled egg coated in spiced batter and fried."
  },
  {
    "id": 180,
    "name": "Chicken Spring Roll",
    "category": "Snacks",
    "type": "NON_VEG",
    "price": 180,
    "description": "Crispy rolls filled with seasoned chicken."
  },
  {
    "id": 181,
    "name": "Chicken Curry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 220,
    "description": "Traditional chicken curry with aromatic spices."
  },
  {
    "id": 182,
    "name": "Andhra Chicken Curry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 240,
    "description": "Spicy Andhra-style chicken curry."
  },
  {
    "id": 183,
    "name": "Butter Chicken",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 260,
    "description": "Creamy tomato-based chicken curry."
  },
  {
    "id": 184,
    "name": "Kadai Chicken",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 250,
    "description": "Chicken cooked with capsicum and kadai spices."
  },
  {
    "id": 185,
    "name": "Chicken Tikka Masala",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 270,
    "description": "Grilled chicken in rich spiced tomato gravy."
  },
  {
    "id": 186,
    "name": "Chicken Chettinad",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 260,
    "description": "South Indian chicken curry with roasted spices."
  },
  {
    "id": 187,
    "name": "Chicken Korma",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 270,
    "description": "Mild creamy chicken curry with nuts and spices."
  },
  {
    "id": 188,
    "name": "Chicken Pepper Masala",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 250,
    "description": "Chicken cooked with freshly ground pepper."
  },
  {
    "id": 189,
    "name": "Chicken Do Pyaza",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 250,
    "description": "Chicken cooked with onions and aromatic spices."
  },
  {
    "id": 190,
    "name": "Chicken Saagwala",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 260,
    "description": "Chicken cooked in creamy spinach gravy."
  },
  {
    "id": 191,
    "name": "Mutton Curry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 320,
    "description": "Tender mutton cooked in traditional spices."
  },
  {
    "id": 192,
    "name": "Andhra Mutton Curry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 340,
    "description": "Spicy Andhra-style mutton curry."
  },
  {
    "id": 193,
    "name": "Mutton Rogan Josh",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 350,
    "description": "Slow-cooked mutton in aromatic Kashmiri spices."
  },
  {
    "id": 194,
    "name": "Mutton Kadai",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 340,
    "description": "Mutton cooked with capsicum and kadai spices."
  },
  {
    "id": 195,
    "name": "Mutton Pepper Fry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 350,
    "description": "Spicy dry mutton preparation with black pepper."
  },
  {
    "id": 196,
    "name": "Fish Curry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 240,
    "description": "Fish cooked in traditional spicy gravy."
  },
  {
    "id": 197,
    "name": "Andhra Fish Curry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 250,
    "description": "Tangy and spicy Andhra-style fish curry."
  },
  {
    "id": 198,
    "name": "Prawn Masala",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 290,
    "description": "Prawns cooked in thick onion-tomato masala."
  },
  {
    "id": 199,
    "name": "Prawn Curry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 300,
    "description": "Juicy prawns cooked in aromatic curry."
  },
  {
    "id": 200,
    "name": "Egg Masala Curry",
    "category": "Dinner",
    "type": "NON_VEG",
    "price": 180,
    "description": "Boiled eggs cooked in spicy masala gravy."
  },
  {
    "id": 201,
    "name": "Egg Milkshake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 140,
    "description": "Creamy milkshake blended with egg and milk."
  },
  {
    "id": 202,
    "name": "Egg Banana Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 150,
    "description": "Banana milkshake blended with fresh egg."
  },
  {
    "id": 203,
    "name": "Egg Chocolate Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 160,
    "description": "Chocolate milkshake blended with egg."
  },
  {
    "id": 204,
    "name": "Egg Vanilla Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 150,
    "description": "Vanilla milkshake blended with fresh egg."
  },
  {
    "id": 205,
    "name": "Egg Coffee Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 160,
    "description": "Cold coffee blended with egg and milk."
  },
  {
    "id": 206,
    "name": "Egg Mango Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 160,
    "description": "Mango milkshake blended with egg."
  },
  {
    "id": 207,
    "name": "Egg Strawberry Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 170,
    "description": "Strawberry milkshake blended with egg."
  },
  {
    "id": 208,
    "name": "Egg Badam Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 180,
    "description": "Almond milkshake blended with egg."
  },
  {
    "id": 209,
    "name": "Egg Cashew Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 180,
    "description": "Cashew milkshake blended with egg."
  },
  {
    "id": 210,
    "name": "Egg Dry Fruit Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 200,
    "description": "Rich dry-fruit shake blended with egg."
  },
  {
    "id": 211,
    "name": "Chicken Soup",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 140,
    "description": "Hot chicken soup with vegetables and herbs."
  },
  {
    "id": 212,
    "name": "Chicken Clear Soup",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 130,
    "description": "Light clear soup with chicken and vegetables."
  },
  {
    "id": 213,
    "name": "Chicken Hot & Sour Soup",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 150,
    "description": "Spicy Indo-Chinese chicken soup."
  },
  {
    "id": 214,
    "name": "Chicken Manchow Soup",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 160,
    "description": "Spicy chicken Manchow soup with crispy noodles."
  },
  {
    "id": 215,
    "name": "Mutton Soup",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 170,
    "description": "Traditional mutton broth with spices."
  },
  {
    "id": 216,
    "name": "Mutton Pepper Soup",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 180,
    "description": "Pepper-flavoured mutton broth."
  },
  {
    "id": 217,
    "name": "Fish Soup",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 160,
    "description": "Light soup prepared with fish and herbs."
  },
  {
    "id": 218,
    "name": "Prawn Soup",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 180,
    "description": "Warm soup with prawns and vegetables."
  },
  {
    "id": 219,
    "name": "Chicken Bone Broth",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 170,
    "description": "Slow-cooked chicken bone broth."
  },
  {
    "id": 220,
    "name": "Chicken Protein Shake",
    "category": "Drinks",
    "type": "NON_VEG",
    "price": 220,
    "description": "High-protein shake with chicken and dairy ingredients."
  },
  {
    "id": 221,
    "name": "Egg Pudding",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 120,
    "description": "Soft creamy pudding prepared with eggs and milk."
  },
  {
    "id": 222,
    "name": "Caramel Egg Custard",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 130,
    "description": "Classic egg custard topped with caramel."
  },
  {
    "id": 223,
    "name": "Egg Caramel Pudding",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 130,
    "description": "Silky egg pudding with caramel sauce."
  },
  {
    "id": 224,
    "name": "Egg Halwa",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 140,
    "description": "Rich sweet preparation made with eggs and milk."
  },
  {
    "id": 225,
    "name": "Egg Kesari",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 130,
    "description": "Sweet egg-based dessert flavoured with saffron."
  },
  {
    "id": 226,
    "name": "Egg Malpua",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 150,
    "description": "Soft malpua prepared with egg and served with syrup."
  },
  {
    "id": 227,
    "name": "Egg Pancake",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 140,
    "description": "Sweet fluffy pancake prepared with egg and milk."
  },
  {
    "id": 228,
    "name": "Egg Waffle",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 160,
    "description": "Crispy waffle prepared with egg and served with syrup."
  },
  {
    "id": 229,
    "name": "Egg French Toast",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 130,
    "description": "Sweet bread toast prepared with egg and milk."
  },
  {
    "id": 230,
    "name": "Honey Egg Toast",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 140,
    "description": "Egg toast served with honey."
  },
  {
    "id": 231,
    "name": "Chocolate Egg Cake",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 150,
    "description": "Soft chocolate cake prepared with eggs."
  },
  {
    "id": 232,
    "name": "Vanilla Egg Cake",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 140,
    "description": "Soft vanilla cake prepared with eggs."
  },
  {
    "id": 233,
    "name": "Egg Brownie",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 160,
    "description": "Rich chocolate brownie prepared with eggs."
  },
  {
    "id": 234,
    "name": "Egg Muffin Cake",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 120,
    "description": "Soft sweet muffin prepared with eggs."
  },
  {
    "id": 235,
    "name": "Egg Bread Pudding",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 140,
    "description": "Baked bread pudding with eggs and milk."
  },
  {
    "id": 236,
    "name": "Egg Custard Tart",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 160,
    "description": "Pastry tart filled with creamy egg custard."
  },
  {
    "id": 237,
    "name": "Egg Cream Roll",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 150,
    "description": "Sweet pastry roll filled with cream and egg custard."
  },
  {
    "id": 238,
    "name": "Egg Coconut Pudding",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 140,
    "description": "Coconut pudding prepared with eggs and milk."
  },
  {
    "id": 239,
    "name": "Egg Carrot Cake",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 150,
    "description": "Moist carrot cake prepared with eggs."
  },
  {
    "id": 240,
    "name": "Egg Dry Fruit Cake",
    "category": "Sweets",
    "type": "NON_VEG",
    "price": 180,
    "description": "Rich dry-fruit cake prepared with eggs."
  }
];

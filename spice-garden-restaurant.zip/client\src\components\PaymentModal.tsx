import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Check, QrCode, ArrowRight, ShieldCheck, Loader2 } from 'lucide-react';
import { OrderResponse } from '../services/api';

const money = (n: number) => `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2, minimumFractionDigits: 2 })}`;

interface PaymentModalProps {
  order: OrderResponse;
  onConfirmPayment: (orderId: number) => Promise<void>;
  onClose: () => void;
}

export function PaymentModal({ order, onConfirmPayment, onClose }: PaymentModalProps) {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePaid = async () => {
    setSubmitting(true);
    setError(null);
    try {
      await onConfirmPayment(order.order_id);
    } catch (err: any) {
      setError(err.message || 'Payment confirmation failed');
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-backdrop">
      <div className="checkout-modal" style={{ maxWidth: '440px', width: '100%', padding: '28px' }}>
        <button className="modal-close" onClick={onClose} aria-label="Close modal">
          <X size={20} />
        </button>

        <div style={{ textAlign: 'center', marginBottom: '16px' }}>
          <span className="eyebrow" style={{ letterSpacing: '2px' }}>YOUR ORDER</span>
          <h2 style={{ font: "600 24px 'Playfair Display', serif", margin: '6px 0 2px' }}>
            Order: {order.order_number}
          </h2>
          <p style={{ fontSize: '12px', color: 'var(--muted)', margin: 0 }}>
            Table #{order.table_number} · Spice Garden
          </p>
        </div>

        {/* Order Summary Breakdown */}
        <div className="checkout-list" style={{ padding: '10px 0', borderTop: '1px solid var(--line)', borderBottom: '1px solid var(--line)' }}>
          {order.items.map((item) => (
            <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', padding: '4px 0' }}>
              <span>{item.quantity} × {item.name}</span>
              <strong>{money(item.price * item.quantity)}</strong>
            </div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: 'var(--muted)', marginTop: '8px' }}>
            <span>Subtotal</span>
            <span>{money(order.subtotal)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: 'var(--muted)', margin: '2px 0' }}>
            <span>GST <small>(5%)</small></span>
            <span>{money(order.tax)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '15px', fontWeight: 'bold', marginTop: '6px', color: 'var(--ink)' }}>
            <span>Total</span>
            <strong style={{ color: 'var(--terra)' }}>{money(order.total)}</strong>
          </div>
        </div>

        {/* SCAN TO PAY SECTION */}
        <div style={{ textAlign: 'center', margin: '20px 0 16px', background: '#F8F4EF', borderRadius: '16px', padding: '18px 14px', border: '1px dashed var(--sand)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', marginBottom: '12px', color: 'var(--terra)', fontWeight: 700, fontSize: '11px', letterSpacing: '1.5px' }}>
            <QrCode size={16} /> SCAN TO PAY
          </div>

          <div style={{ background: '#fff', padding: '14px', borderRadius: '12px', display: 'inline-block', boxShadow: '0 4px 15px rgba(0,0,0,0.06)' }}>
            <QRCodeSVG value={order.upi_uri} size={170} level="M" includeMargin={false} />
          </div>

          <div style={{ font: "700 24px 'Playfair Display', serif", color: 'var(--ink)', marginTop: '12px' }}>
            {money(order.total)}
          </div>
          <p style={{ fontSize: '11px', color: 'var(--muted)', margin: '4px 0 0' }}>
            Scan using any compatible UPI app (GPay, PhonePe, Paytm)
          </p>
        </div>

        {error && (
          <div style={{ color: '#B54D43', fontSize: '12px', textAlign: 'center', marginBottom: '12px' }}>
            {error}
          </div>
        )}

        {/* I HAVE PAID BUTTON */}
        <button
          className="checkout-btn"
          onClick={handlePaid}
          disabled={submitting}
          style={{ width: '100%', height: '48px', fontSize: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
        >
          {submitting ? (
            <>
              <Loader2 className="animate-spin" size={18} /> Confirming Payment...
            </>
          ) : (
            <>
              <Check size={18} /> I HAVE PAID
            </>
          )}
        </button>

        <p className="demo-note" style={{ fontSize: '10px', color: '#A4978E', textAlign: 'center', marginTop: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
          <ShieldCheck size={12} /> Demo mode payment verification
        </p>
      </div>
    </div>
  );
}

import React, { useMemo, useState, useEffect } from 'react';
import {
  ArrowRight, Check, ChevronDown, Clock3, Minus, Plus, Search, ShoppingBag, Sparkles, Utensils,
  X, Zap, Loader2
} from 'lucide-react';
import { fetchMenu, createOrder, confirmOrderPayment, MenuItem, OrderResponse } from '@/services/api';
import { PaymentModal } from '@/components/PaymentModal';

const categories = ['All', 'Breakfast', 'Lunch', 'Snacks', 'Dinner', 'Drinks', 'Sweets'];
const money = (n: number) => `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;

function Logo() {
  return (
    <div className="brand">
      <div className="brand-mark">
        <Utensils size={21} strokeWidth={2.1} />
      </div>
      <div>
        <div className="brand-name" style={{ font: "700 19px 'Playfair Display', serif", color: "#fff", letterSpacing: "0.5px", lineHeight: "1.1" }}>
          Spice Garden
        </div>
        <div className="brand-en" style={{ color: "#D5A47D", fontSize: "8px", letterSpacing: "2.5px", marginTop: "2px" }}>
          RESTAURANT
        </div>
      </div>
    </div>
  );
}

function FoodTypeFilter({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="type-filters" role="group" aria-label="Food type filters">
      {[
        ['ALL', 'All'],
        ['VEG', 'Veg'],
        ['NON_VEG', 'Non-veg']
      ].map(([key, label]) => (
        <button
          key={key}
          className={`type-pill ${value === key ? `active ${key.toLowerCase()}` : ''}`}
          onClick={() => onChange(key)}
        >
          <span className={key === 'VEG' ? 'dot veg-dot' : key === 'NON_VEG' ? 'dot nonveg-dot' : ''}>
            {key === 'VEG' ? '●' : key === 'NON_VEG' ? '●' : ''}
          </span>
          {label}
        </button>
      ))}
    </div>
  );
}

function FoodCard({ item, onAdd, added }: { item: MenuItem; onAdd: (i: MenuItem) => void; added: boolean }) {
  const isVeg = item.type === 'VEG';
  return (
    <article className="food-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div className="food-body" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <div className="food-meta" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span>{item.category}</span>
            <div className={`food-tag ${isVeg ? 'veg' : 'nonveg'}`} style={{ position: 'static', padding: '3px 6px' }}>
              <span>●</span>{isVeg ? 'VEG' : 'NON-VEG'}
            </div>
          </div>
          <span className="prep"><Clock3 size={12} /> 15–25 min</span>
        </div>
        <h3>{item.name}</h3>
        <p style={{ flexGrow: 1 }}>{item.description}</p>
        <div className="food-bottom" style={{ marginTop: 'auto' }}>
          <strong>{money(item.price)}</strong>
          <button className={`add-btn ${added ? 'added' : ''}`} onClick={() => onAdd(item)}>
            {added ? <><Check size={15} /> Added</> : <><Plus size={16} /> Add</>}
          </button>
        </div>
      </div>
    </article>
  );
}

function CartDrawer({ open, onClose, cart, onQty, onCheckout, loading }: {
  open: boolean;
  onClose: () => void;
  cart: Array<MenuItem & { quantity: number }>;
  onQty: (id: number, delta: number) => void;
  onCheckout: () => void;
  loading: boolean;
}) {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const gst = subtotal * 0.05;
  const total = subtotal + gst;

  return (
    <>
      <div className={`drawer-overlay ${open ? 'show' : ''}`} onClick={onClose} />
      <aside className={`cart-drawer ${open ? 'open' : ''}`} aria-label="Shopping cart">
        <div className="drawer-head">
          <div>
            <span className="eyebrow">YOUR ORDER</span>
            <h2>Your Order Basket</h2>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close cart">
            <X size={21} />
          </button>
        </div>

        {cart.length === 0 ? (
          <div className="empty-cart">
            <div className="empty-icon"><ShoppingBag size={34} /></div>
            <h3>Your cart is empty</h3>
            <p>Add some delicious dishes<br />from Spice Garden to get started.</p>
          </div>
        ) : (
          <>
            <div className="cart-items">
              {cart.map(item => (
                <div className="cart-item" key={item.id}>
                  <div className="cart-item-main">
                    <div className="cart-item-name">{item.name}</div>
                    <div className="cart-item-price">{money(item.price)} each</div>
                    <div className="qty">
                      <button onClick={() => onQty(item.id, -1)} aria-label={`Decrease ${item.name}`}><Minus size={13} /></button>
                      <span>{item.quantity}</span>
                      <button onClick={() => onQty(item.id, 1)} aria-label={`Increase ${item.name}`}><Plus size={13} /></button>
                    </div>
                  </div>
                  <strong className="cart-line-total">{money(item.price * item.quantity)}</strong>
                </div>
              ))}
            </div>
            <div className="bill">
              <div><span>Subtotal</span><strong>{money(subtotal)}</strong></div>
              <div><span>GST <small>(5%)</small></span><strong>{money(gst)}</strong></div>
              <div className="bill-total"><span>Estimated Total</span><strong>{money(total)}</strong></div>
            </div>
            <button className="checkout-btn" onClick={onCheckout} disabled={loading}>
              {loading ? <><Loader2 className="animate-spin" size={18} /> Processing...</> : <>Proceed to Checkout <ArrowRight size={17} /></>}
            </button>
            <p className="secure-note"><Zap size={13} /> Secure UPI payment on checkout</p>
          </>
        )}
      </aside>
    </>
  );
}

function Confirmation({ order, onBack }: { order: OrderResponse; onBack: () => void }) {
  return (
    <div className="modal-backdrop">
      <div className="confirmation">
        <div className="success-mark"><Check size={30} /></div>
        <span className="eyebrow">ORDER CONFIRMED</span>
        <h2>Order placed.</h2>
        <p>Thank you for ordering from Spice Garden. Your kitchen is preparing your order.</p>

        <div className="order-info">
          <div><span>STATUS</span><strong>{order.status}</strong></div>
          <div><span>PAYMENT</span><strong>{order.payment_status}</strong></div>
          <div><span>ORDER ID</span><strong>{order.order_number}</strong></div>
        </div>

        <div className="confirm-items">
          {order.items.map((item, idx) => (
            <div key={idx}>
              <span>{item.quantity} × {item.name}</span>
              <strong>{money(item.price * item.quantity)}</strong>
            </div>
          ))}
        </div>

        <div className="confirmation-total">
          <span>Total paid</span>
          <strong>{money(order.total)}</strong>
        </div>

        <button className="checkout-btn" onClick={onBack}>
          Back to menu <ArrowRight size={17} />
        </button>
      </div>
    </div>
  );
}

export default function Home() {
  const [menuList, setMenuList] = useState<MenuItem[]>([]);
  const [loadingMenu, setLoadingMenu] = useState(true);
  const [menuError, setMenuError] = useState<string | null>(null);

  const [type, setType] = useState('ALL');
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');

  const [cart, setCart] = useState<Array<MenuItem & { quantity: number }>>([]);
  const [cartOpen, setCartOpen] = useState(false);

  const [placingOrder, setPlacingOrder] = useState(false);
  const [pendingOrder, setPendingOrder] = useState<OrderResponse | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<OrderResponse | null>(null);

  const [addedId, setAddedId] = useState<number | null>(null);
  const [shown, setShown] = useState(24);

  // Fetch menu from backend API
  useEffect(() => {
    let isMounted = true;
    setLoadingMenu(true);
    fetchMenu(type, category)
      .then(data => {
        if (isMounted) {
          setMenuList(data);
          setLoadingMenu(false);
        }
      })
      .catch(err => {
        if (isMounted) {
          setMenuError(err.message || 'Failed to load menu');
          setLoadingMenu(false);
        }
      });
    return () => { isMounted = false; };
  }, [type, category]);

  const filtered = useMemo(() => {
    return menuList.filter(item =>
      `${item.name} ${item.description} ${item.category}`.toLowerCase().includes(query.toLowerCase())
    );
  }, [menuList, query]);

  const itemCount = cart.reduce((sum, i) => sum + i.quantity, 0);

  const addToCart = (item: MenuItem) => {
    setCart(prev =>
      prev.some(i => i.id === item.id)
        ? prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)
        : [...prev, { ...item, quantity: 1 }]
    );
    setAddedId(item.id);
    window.setTimeout(() => setAddedId(null), 900);
  };

  const onQty = (id: number, delta: number) => {
    setCart(prev =>
      prev
        .map(i => i.id === id ? { ...i, quantity: i.quantity + delta } : i)
        .filter(i => i.quantity > 0)
    );
  };

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setPlacingOrder(true);
    try {
      const orderItems = cart.map(i => ({ id: i.id, quantity: i.quantity }));
      const orderData = await createOrder(orderItems, 1);
      setPendingOrder(orderData);
      setCartOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to create order');
    } finally {
      setPlacingOrder(false);
    }
  };

  const handleConfirmPayment = async (orderId: number) => {
    const updated = await confirmOrderPayment(orderId);
    setPendingOrder(null);
    setConfirmedOrder(updated);
    setCart([]);
  };

  return (
    <div className="site-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <Logo />
          <button
            className="cart-trigger"
            onClick={() => setCartOpen(true)}
            aria-label={`Open cart with ${itemCount} items`}
          >
            <ShoppingBag size={20} />
            <span>Cart</span>
            {itemCount > 0 && <b>{itemCount}</b>}
          </button>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-orb orb-one" />
          <div className="hero-orb orb-two" />
          <div className="container hero-content">
            <div className="hero-copy">
              <div className="kicker"><span /> WELCOME TO SPICE GARDEN</div>
              <h1>Good food.<br /><em>Good memories.</em></h1>
              <p>Explore a tableful of soulful Indian flavours, crafted with fresh ingredients and authentic spices.</p>
              <div className="hero-actions">
                <button className="hero-cta" onClick={() => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' })}>
                  Explore the menu <ArrowRight size={17} />
                </button>
                <span className="hero-note"><Sparkles size={14} /> Freshly prepared, always</span>
              </div>
            </div>
            <div className="hero-art">
              <div className="art-plate">
                <div className="plate-inner">
                  <small>EST. 2024</small>
                </div>
              </div>
              <div className="art-card">
                <span>Today's<br /><b>special</b></span>
                <strong>✦</strong>
              </div>
            </div>
          </div>
          <div className="hero-bottom">
            <div><strong>240+</strong><span>dishes to<br />discover</span></div>
            <div><strong>100%</strong><span>made with<br />care</span></div>
            <div><strong>5★</strong><span>table-side<br />experience</span></div>
          </div>
        </section>

        <section className="menu-section container" id="menu">
          <div className="search-wrap">
            <Search size={19} />
            <input
              value={query}
              onChange={e => { setQuery(e.target.value); setShown(24); }}
              placeholder="Search dishes, flavours, ingredients..."
              aria-label="Search dishes"
            />
            {query && (
              <button onClick={() => setQuery('')} aria-label="Clear search">
                <X size={16} />
              </button>
            )}
            <kbd>⌘ K</kbd>
          </div>

          <div className="filter-row">
            <FoodTypeFilter value={type} onChange={v => { setType(v); setShown(24); }} />
            <div className="category-scroll">
              {categories.map(c => (
                <button
                  key={c}
                  className={category === c ? 'category active' : 'category'}
                  onClick={() => { setCategory(c); setShown(24); }}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="menu-heading">
            <div>
              <span className="eyebrow">{category === 'All' ? 'EXPLORE OUR MENU' : `${category.toUpperCase()} COLLECTION`}</span>
              <h2>{category === 'All' ? 'What are you craving?' : `A little ${category.toLowerCase()} magic`}</h2>
            </div>
            <div className="result-count">
              <strong>{filtered.length}</strong>
              <span>{filtered.length === 1 ? 'dish' : 'dishes'} found</span>
            </div>
          </div>

          {loadingMenu ? (
            <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--muted)' }}>
              <Loader2 className="animate-spin" size={32} style={{ margin: 'auto', marginBottom: '12px' }} />
              <p>Loading fresh dishes from Spice Garden...</p>
            </div>
          ) : menuError ? (
            <div className="no-results">
              <Search size={28} />
              <h3>Error loading menu</h3>
              <p>{menuError}</p>
            </div>
          ) : filtered.length ? (
            <>
              <div className="menu-grid">
                {filtered.slice(0, shown).map(item => (
                  <FoodCard
                    key={item.id}
                    item={item}
                    onAdd={addToCart}
                    added={addedId === item.id}
                  />
                ))}
              </div>
              {shown < filtered.length && (
                <button className="load-more" onClick={() => setShown(s => s + 24)}>
                  Show more dishes <ChevronDown size={17} />
                </button>
              )}
            </>
          ) : (
            <div className="no-results">
              <Search size={28} />
              <h3>No dishes found</h3>
              <p>Try another search or clear your filters.</p>
              <button onClick={() => { setQuery(''); setType('ALL'); setCategory('All'); }}>Reset filters</button>
            </div>
          )}
        </section>
      </main>

      <footer>
        <div className="container footer-inner">
          <Logo />
          <p>Made for good food & better memories.</p>
          <span>© 2024 Spice Garden Restaurant</span>
        </div>
      </footer>

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onQty={onQty}
        onCheckout={handleCheckout}
        loading={placingOrder}
      />

      {pendingOrder && (
        <PaymentModal
          order={pendingOrder}
          onConfirmPayment={handleConfirmPayment}
          onClose={() => setPendingOrder(null)}
        />
      )}

      {confirmedOrder && (
        <Confirmation
          order={confirmedOrder}
          onBack={() => setConfirmedOrder(null)}
        />
      )}
    </div>
  );
}

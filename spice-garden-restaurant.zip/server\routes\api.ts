import { Router, Request, Response } from 'express';
import { pool, checkDbConnection } from '../db';
import { menuItems as fallbackMenuItems } from '../../client/src/data/menu.js';

const router = Router();

// In-memory fallback order storage if MySQL is offline during local test
const fallbackOrders = new Map<number, any>();
let fallbackOrderCounter = 1;

// GET /api/health
router.get('/health', async (_req: Request, res: Response) => {
  const dbConnected = await checkDbConnection();
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    dbConnected,
    service: 'Spice Garden API'
  });
});

// GET /api/menu
// Filters: food_type (VEG, NON_VEG), meal_type / category (BREAKFAST, LUNCH, SNACKS, DINNER, DRINKS, SWEETS)
router.get('/menu', async (req: Request, res: Response) => {
  const foodType = req.query.food_type ? String(req.query.food_type).toUpperCase() : undefined;
  const mealType = req.query.meal_type || req.query.category
    ? String(req.query.meal_type || req.query.category).toUpperCase()
    : undefined;

  const isConnected = await checkDbConnection();

  if (isConnected && pool) {
    try {
      let querySql = `
        SELECT m.item_id AS id, m.name, m.description, m.price, m.food_type AS type,
               c.category_name AS category, m.meal_type AS mealType, m.is_available
        FROM menu_items m
        JOIN menu_categories c ON m.category_id = c.category_id
        WHERE m.is_available = 1
      `;
      const params: any[] = [];

      if (foodType && foodType !== 'ALL') {
        querySql += ` AND m.food_type = ?`;
        params.push(foodType);
      }

      if (mealType && mealType !== 'ALL') {
        querySql += ` AND (UPPER(m.meal_type) = ? OR UPPER(c.category_name) = ?)`;
        params.push(mealType, mealType);
      }

      querySql += ` ORDER BY m.item_id ASC`;

      const [rows] = await pool.query(querySql, params);
      const items = (rows as any[]).map(row => ({
        ...row,
        price: Number(row.price),
        is_available: Boolean(row.is_available)
      }));

      return res.json(items);
    } catch (err) {
      console.error('MySQL query error in GET /api/menu, using fallback:', err);
    }
  }

  // Fallback to memory seed data if DB is offline
  let filtered = fallbackMenuItems.map((item: any) => ({
    id: item.id,
    name: item.name,
    description: item.description,
    price: Number(item.price),
    type: item.type,
    category: item.category,
    mealType: item.category.toUpperCase(),
    is_available: true
  }));

  if (foodType && foodType !== 'ALL') {
    filtered = filtered.filter((i: any) => i.type === foodType);
  }

  if (mealType && mealType !== 'ALL') {
    filtered = filtered.filter((i: any) =>
      i.category.toUpperCase() === mealType || i.mealType === mealType
    );
  }

  res.json(filtered);
});

// Helper to construct UPI URI
function buildUpiUri(orderNumber: string, total: number): string {
  const upiId = process.env.UPI_ID || 'restaurant@upi';
  const upiName = process.env.UPI_NAME || 'Spice Garden';
  const amountStr = total.toFixed(2);
  const note = `Order ${orderNumber}`;
  return `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(upiName)}&am=${amountStr}&tn=${encodeURIComponent(note)}&cu=INR`;
}

// POST /api/orders
router.post('/orders', async (req: Request, res: Response) => {
  const { table_number = 1, items } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Order must contain at least one item' });
  }

  for (const item of items) {
    if (!item.id || !item.quantity || item.quantity <= 0) {
      return res.status(400).json({ error: 'Invalid item format or quantity' });
    }
  }

  const itemIds = items.map((i: any) => Number(i.id));
  const isConnected = await checkDbConnection();

  let orderItemsWithPrice: Array<{ id: number; name: string; price: number; quantity: number }> = [];
  let subtotal = 0;

  if (isConnected && pool) {
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();

      const [dbItems] = await conn.query(
        `SELECT item_id AS id, name, price, is_available FROM menu_items WHERE item_id IN (?)`,
        [itemIds]
      );

      const dbItemsMap = new Map<number, any>();
      (dbItems as any[]).forEach((row: any) => {
        dbItemsMap.set(row.id, row);
      });

      for (const reqItem of items) {
        const found = dbItemsMap.get(Number(reqItem.id));
        if (!found) {
          await conn.rollback();
          conn.release();
          return res.status(400).json({ error: `Item ID ${reqItem.id} not found` });
        }
        if (!found.is_available) {
          await conn.rollback();
          conn.release();
          return res.status(400).json({ error: `Item "${found.name}" is currently unavailable` });
        }

        const price = Number(found.price);
        const qty = Number(reqItem.quantity);
        subtotal += price * qty;
        orderItemsWithPrice.push({
          id: found.id,
          name: found.name,
          price,
          quantity: qty
        });
      }

      const tax = Number((subtotal * 0.05).toFixed(2)); // 5% GST
      const total = Number((subtotal + tax).toFixed(2));

      // Reserve order ID to format order_number VIR-XXXX
      const [result] = await conn.query(
        `INSERT INTO orders (order_number, table_number, subtotal, tax, total, status, payment_status)
         VALUES ('TEMP', ?, ?, ?, ?, 'PLACED', 'PENDING_PAYMENT')`,
        [table_number, subtotal, tax, total]
      );

      const orderId = (result as any).insertId;
      const orderNumber = `VIR-${orderId.toString().padStart(4, '0')}`;

      await conn.query(
        `UPDATE orders SET order_number = ? WHERE order_id = ?`,
        [orderNumber, orderId]
      );

      for (const oi of orderItemsWithPrice) {
        await conn.query(
          `INSERT INTO order_items (order_id, item_id, quantity, price) VALUES (?, ?, ?, ?)`,
          [orderId, oi.id, oi.quantity, oi.price]
        );
      }

      await conn.commit();
      conn.release();

      const upiUri = buildUpiUri(orderNumber, total);

      return res.status(201).json({
        order_id: orderId,
        order_number: orderNumber,
        table_number,
        subtotal,
        tax,
        total,
        status: 'PLACED',
        payment_status: 'PENDING_PAYMENT',
        created_at: new Date().toISOString(),
        items: orderItemsWithPrice,
        upi_uri: upiUri
      });
    } catch (err) {
      await conn.rollback();
      conn.release();
      console.error('Transaction failed in POST /api/orders:', err);
      return res.status(500).json({ error: 'Failed to process order' });
    }
  }

  // Fallback memory order processing if MySQL connection is unavailable
  const fallbackMap = new Map<number, any>();
  fallbackMenuItems.forEach((i: any) => fallbackMap.set(i.id, i));

  for (const reqItem of items) {
    const found = fallbackMap.get(Number(reqItem.id));
    if (!found) {
      return res.status(400).json({ error: `Item ID ${reqItem.id} not found` });
    }
    const price = Number(found.price);
    const qty = Number(reqItem.quantity);
    subtotal += price * qty;
    orderItemsWithPrice.push({
      id: found.id,
      name: found.name,
      price,
      quantity: qty
    });
  }

  const tax = Number((subtotal * 0.05).toFixed(2));
  const total = Number((subtotal + tax).toFixed(2));
  const orderId = fallbackOrderCounter++;
  const orderNumber = `VIR-${orderId.toString().padStart(4, '0')}`;

  const createdOrder = {
    order_id: orderId,
    order_number: orderNumber,
    table_number,
    subtotal,
    tax,
    total,
    status: 'PLACED',
    payment_status: 'PENDING_PAYMENT',
    created_at: new Date().toISOString(),
    items: orderItemsWithPrice,
    upi_uri: buildUpiUri(orderNumber, total)
  };

  fallbackOrders.set(orderId, createdOrder);
  res.status(201).json(createdOrder);
});

// PATCH /api/orders/:id/payment
router.patch('/orders/:id/payment', async (req: Request, res: Response) => {
  const { id } = req.params;
  const paymentStatus = req.body.status || req.body.payment_status || 'PAID';

  const validPaymentStatuses = ['PENDING_PAYMENT', 'PAID', 'PAYMENT_FAILED'];
  if (!validPaymentStatuses.includes(paymentStatus)) {
    return res.status(400).json({ error: `Invalid payment status. Allowed: ${validPaymentStatuses.join(', ')}` });
  }

  const isConnected = await checkDbConnection();

  if (isConnected && pool) {
    try {
      const [rows] = await pool.query(
        `SELECT order_id FROM orders WHERE order_id = ? OR order_number = ?`,
        [id, id]
      );
      const orders = rows as any[];
      if (orders.length === 0) {
        return res.status(404).json({ error: 'Order not found' });
      }

      const orderId = orders[0].order_id;
      await pool.query(
        `UPDATE orders SET payment_status = ? WHERE order_id = ?`,
        [paymentStatus, orderId]
      );

      // Return updated order
      const [updatedRows] = await pool.query(
        `SELECT order_id, order_number, table_number, subtotal, tax, total, status, payment_status, created_at FROM orders WHERE order_id = ?`,
        [orderId]
      );
      const updatedOrder = (updatedRows as any[])[0];
      return res.json({
        ...updatedOrder,
        subtotal: Number(updatedOrder.subtotal),
        tax: Number(updatedOrder.tax),
        total: Number(updatedOrder.total)
      });
    } catch (err) {
      console.error('Error updating payment status:', err);
      return res.status(500).json({ error: 'Failed to update payment status' });
    }
  }

  // Fallback memory order update
  const numericId = Number(id);
  const foundOrder = fallbackOrders.get(numericId) || Array.from(fallbackOrders.values()).find(o => o.order_number === id);
  if (!foundOrder) {
    return res.status(404).json({ error: 'Order not found' });
  }
  foundOrder.payment_status = paymentStatus;
  res.json(foundOrder);
});

// GET /api/orders/:id
router.get('/orders/:id', async (req: Request, res: Response) => {
  const { id } = req.params;
  const isConnected = await checkDbConnection();

  if (isConnected && pool) {
    try {
      const [orderRows] = await pool.query(
        `SELECT order_id, order_number, table_number, subtotal, tax, total, status, payment_status, created_at FROM orders WHERE order_id = ? OR order_number = ?`,
        [id, id]
      );

      const orders = orderRows as any[];
      if (orders.length === 0) {
        return res.status(404).json({ error: 'Order not found' });
      }

      const order = orders[0];
      const [itemRows] = await pool.query(
        `SELECT oi.order_item_id, oi.item_id AS id, oi.quantity, oi.price, m.name
         FROM order_items oi
         JOIN menu_items m ON oi.item_id = m.item_id
         WHERE oi.order_id = ?`,
        [order.order_id]
      );

      return res.json({
        ...order,
        subtotal: Number(order.subtotal),
        tax: Number(order.tax),
        total: Number(order.total),
        items: (itemRows as any[]).map(i => ({ ...i, price: Number(i.price) }))
      });
    } catch (err) {
      console.error('Error fetching order:', err);
      return res.status(500).json({ error: 'Failed to fetch order' });
    }
  }

  const numericId = Number(id);
  const foundOrder = fallbackOrders.get(numericId) || Array.from(fallbackOrders.values()).find(o => o.order_number === id);
  if (!foundOrder) {
    return res.status(404).json({ error: 'Order not found' });
  }
  res.json(foundOrder);
});

// PATCH /api/orders/:id/status
router.patch('/orders/:id/status', async (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;

  const validStatuses = ['PLACED', 'PREPARING', 'READY', 'COMPLETED', 'CANCELLED'];
  if (!status || !validStatuses.includes(status)) {
    return res.status(400).json({ error: `Invalid status. Allowed values: ${validStatuses.join(', ')}` });
  }

  const isConnected = await checkDbConnection();

  if (isConnected && pool) {
    try {
      const [rows] = await pool.query(
        `SELECT order_id FROM orders WHERE order_id = ? OR order_number = ?`,
        [id, id]
      );
      const orders = rows as any[];
      if (orders.length === 0) {
        return res.status(404).json({ error: 'Order not found' });
      }

      const orderId = orders[0].order_id;
      await pool.query(
        `UPDATE orders SET status = ? WHERE order_id = ?`,
        [status, orderId]
      );

      const [updatedRows] = await pool.query(
        `SELECT order_id, order_number, table_number, subtotal, tax, total, status, payment_status, created_at FROM orders WHERE order_id = ?`,
        [orderId]
      );
      const updatedOrder = (updatedRows as any[])[0];
      return res.json({
        ...updatedOrder,
        subtotal: Number(updatedOrder.subtotal),
        tax: Number(updatedOrder.tax),
        total: Number(updatedOrder.total)
      });
    } catch (err) {
      console.error('Error updating order status:', err);
      return res.status(500).json({ error: 'Failed to update order status' });
    }
  }

  const numericId = Number(id);
  const foundOrder = fallbackOrders.get(numericId) || Array.from(fallbackOrders.values()).find(o => o.order_number === id);
  if (!foundOrder) {
    return res.status(404).json({ error: 'Order not found' });
  }
  foundOrder.status = status;
  res.json(foundOrder);
});

export default router;

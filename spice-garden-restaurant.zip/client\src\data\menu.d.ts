export declare const menuItems: Array<{
  id: number;
  name: string;
  category: string;
  type: string;
  price: number;
  description: string;
}>;

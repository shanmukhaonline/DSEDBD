export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  type: 'VEG' | 'NON_VEG';
  category: string;
  mealType?: string;
  is_available?: boolean;
}

export interface OrderItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}

export interface OrderResponse {
  order_id: number;
  order_number: string;
  table_number: number;
  subtotal: number;
  tax: number;
  total: number;
  status: 'PLACED' | 'PREPARING' | 'READY' | 'COMPLETED' | 'CANCELLED';
  payment_status: 'PENDING_PAYMENT' | 'PAID' | 'PAYMENT_FAILED';
  created_at: string;
  items: OrderItem[];
  upi_uri: string;
}

export async function fetchMenu(foodType?: string, mealType?: string): Promise<MenuItem[]> {
  const params = new URLSearchParams();
  if (foodType && foodType !== 'ALL') params.append('food_type', foodType);
  if (mealType && mealType !== 'All') params.append('meal_type', mealType);

  const queryString = params.toString();
  const url = `/api/menu${queryString ? `?${queryString}` : ''}`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Failed to fetch menu: ${res.statusText}`);
  }
  return res.json();
}

export async function createOrder(items: { id: number; quantity: number }[], tableNumber: number = 1): Promise<OrderResponse> {
  const res = await fetch('/api/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ items, table_number: tableNumber })
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Failed to create order: ${res.statusText}`);
  }
  return res.json();
}

export async function confirmOrderPayment(orderId: number | string): Promise<OrderResponse> {
  const res = await fetch(`/api/orders/${orderId}/payment`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status: 'PAID' })
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Failed to confirm payment: ${res.statusText}`);
  }
  return res.json();
}
